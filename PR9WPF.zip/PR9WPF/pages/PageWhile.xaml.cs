﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR9WPF.pages
{
    /// <summary>
    /// Логика взаимодействия для PageWhile.xaml
    /// </summary>
    public partial class PageWhile : Page
    {
        public PageWhile()
        {
            InitializeComponent();
        }
        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            double X0 = double.Parse(txtX0.Text);
            double Xk = double.Parse(txtXK.Text);
            double dx = double.Parse(txtDX.Text);
            double B = double.Parse(txtB.Text);
            double C = double.Parse(txtC.Text);
            double A = double.Parse(txtA.Text);
            double y = 0;
            while (X0 < Xk)
            {
                X0 += dx;
                y = Math.Pow(10, -2) * B * C / X0 + Math.Cos(Math.Sqrt(Math.Pow(A, 3) * X0));
                FirstTable.Items.Add(y);
            }

        }

        private void btnnext_Click(object sender, RoutedEventArgs e)
        {
            ClsFrame.FrmObject.Navigate(new PageFor());
        }
    }
}
